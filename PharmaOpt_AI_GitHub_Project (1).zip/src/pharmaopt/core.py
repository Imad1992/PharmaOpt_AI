"""Reproducible synthetic data, probabilistic forecasts, and constrained purchasing."""
import numpy as np
import pandas as pd
from scipy.optimize import milp, Bounds, LinearConstraint


def make_data(seed=42, days=240):
    rng = np.random.default_rng(seed)
    products = pd.DataFrame({
        'sku': ['MED-A', 'MED-B', 'MED-C', 'MED-D', 'MED-E'],
        'medicine': ['Product A', 'Product B', 'Product C', 'Product D', 'Product E'],
        'unit_cost': [6.5, 12.0, 4.2, 18.0, 9.0],
        'stock': [115, 55, 190, 35, 80],
        'lead_days': [7, 12, 5, 15, 9],
        'pack_size': [10, 5, 20, 5, 10],
        'max_packs': [30, 20, 25, 15, 20],
        'supplier_reliability': [0.96, 0.86, 0.98, 0.82, 0.92],
    })
    rows = []
    dates = pd.date_range(end=pd.Timestamp('2026-10-31'), periods=days)
    for i, p in products.iterrows():
        base = [14, 8, 21, 5, 11][i]
        for t, date in enumerate(dates):
            seasonal = 1 + .17 * np.sin(2 * np.pi * t / 30 + i)
            weekday = 1.12 if date.dayofweek < 5 else .82
            units = int(rng.poisson(max(.1, base * seasonal * weekday)))
            rows.append((date, p.sku, units))
    demand = pd.DataFrame(rows, columns=['date', 'sku', 'units'])
    return products, demand


def forecast(demand, horizon=30, simulations=2000, seed=42):
    """Empirical weekday bootstrap with 80% predictive intervals; no future-data leakage."""
    rng = np.random.default_rng(seed)
    output = []
    for sku, g in demand.groupby('sku'):
        g = g.sort_values('date')
        last_date = pd.Timestamp(g.date.max())
        for step in range(1, horizon + 1):
            target = last_date + pd.Timedelta(days=step)
            history = g.loc[g.date.dt.dayofweek == target.dayofweek, 'units'].to_numpy()
            if len(history) < 3:
                history = g.units.to_numpy()
            draws = rng.choice(history, size=simulations, replace=True)
            output.append((sku, target, float(draws.mean()), float(np.quantile(draws, .1)), float(np.quantile(draws, .9))))
    return pd.DataFrame(output, columns=['sku', 'date', 'mean', 'p10', 'p90'])


def optimise(products, forecasts, budget=12000, service_quantile='p90'):
    """Integer linear optimisation of packs with budget, capacity and supplier risk penalties.

    Objective minimizes weighted unmet target demand and acquisition costs.
    Shortage slack is allowed to keep the problem feasible under tight budgets.
    """
    if budget < 0:
        raise ValueError('budget must be nonnegative')
    if service_quantile not in ('mean', 'p90'):
        raise ValueError('service_quantile must be mean or p90')
    ps = products.reset_index(drop=True).copy()
    f = forecasts.groupby('sku')[service_quantile].sum()
    n = len(ps)
    target = np.array([float(f.get(sku, 0)) for sku in ps.sku])
    stock = ps.stock.to_numpy(dtype=float)
    pack = ps.pack_size.to_numpy(dtype=float)
    cost = ps.unit_cost.to_numpy(dtype=float) * pack
    reliability = ps.supplier_reliability.to_numpy(dtype=float)
    # Variables: n integer pack counts and n continuous shortage slack values.
    # Shortage penalty per unit is intentionally higher than unit acquisition cost.
    penalty = ps.unit_cost.to_numpy(dtype=float) * (4 + 2 * (1 - reliability))
    c = np.r_[cost * (1 + .15 * (1 - reliability)), penalty]
    A = np.zeros((n + 1, 2 * n))
    A[0, :n] = cost
    for i in range(n):
        A[i + 1, i] = pack[i]
        A[i + 1, n + i] = 1
    constraints = LinearConstraint(A, np.r_[0, target - stock], np.r_[budget, np.full(n, np.inf)])
    result = milp(c=c, integrality=np.r_[np.ones(n), np.zeros(n)], bounds=Bounds(np.zeros(2*n), np.r_[ps.max_packs.to_numpy(dtype=float), np.full(n, np.inf)]), constraints=constraints, options={'time_limit': 20})
    if result.x is None:
        raise RuntimeError(f'Optimisation failed: {result.message}')
    packs = np.rint(result.x[:n]).astype(int)
    out = ps[['sku', 'medicine', 'stock', 'unit_cost', 'supplier_reliability']].copy()
    out['forecast_demand'] = np.round(target, 1)
    out['order_packs'] = packs
    out['order_units'] = packs * pack.astype(int)
    out['order_cost'] = np.round(packs * cost, 2)
    out['projected_shortage'] = np.maximum(0, target - stock - out.order_units.to_numpy())
    return out


def backtest(demand, horizon=14):
    """Chronological holdout evaluation, with no random train/test shuffle."""
    cutoff = demand.date.max() - pd.Timedelta(days=horizon)
    train = demand[demand.date <= cutoff]
    actual = demand[demand.date > cutoff]
    pred = forecast(train, horizon=horizon)
    merged = actual.merge(pred, on=['sku', 'date'])
    mae = float(np.abs(merged.units - merged['mean']).mean())
    coverage = float(((merged.units >= merged.p10) & (merged.units <= merged.p90)).mean())
    return {'mae': mae, 'interval_80_coverage': coverage, 'holdout_days': horizon}
