"""PharmaOpt AI: synthetic pharmaceutical procurement decision support."""
