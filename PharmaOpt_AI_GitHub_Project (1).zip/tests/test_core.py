from pharmaopt.core import make_data, forecast, optimise, backtest

def test_data_reproducible():
    a, b = make_data()
    c, d = make_data()
    assert a.equals(c) and b.equals(d)

def test_forecast_and_backtest():
    products, demand = make_data()
    p = forecast(demand, horizon=7)
    assert len(p) == 7 * len(products)
    assert (p.p10 <= p['mean']).all() and (p['mean'] <= p.p90).all()
    assert backtest(demand)['mae'] >= 0

def test_budget_and_pack_constraints():
    products, demand = make_data()
    p = forecast(demand, horizon=14)
    for budget in [0, 500, 3000, 15000]:
        orders = optimise(products, p, budget=budget)
        assert orders.order_cost.sum() <= budget + 1e-5
        assert (orders.order_units.to_numpy() % products.pack_size.to_numpy() == 0).all()
        assert (orders.order_packs.to_numpy() <= products.max_packs.to_numpy()).all()
