import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / 'src'))
import streamlit as st
import plotly.express as px
from pharmaopt.core import make_data, forecast, optimise, backtest

st.set_page_config(page_title='PharmaOpt AI', layout='wide')
st.title('PharmaOpt AI | Procurement Decision Support')
st.caption('Demonstration with synthetic medicine demand and suppliers; not for clinical or live procurement use.')
products, demand = make_data()
with st.sidebar:
    st.header('Scenario')
    budget = st.slider('Purchasing budget (£)', 0, 25000, 12000, 500)
    horizon = st.slider('Planning horizon (days)', 7, 60, 30)
    target = st.selectbox('Service target', ['p90', 'mean'], format_func=lambda x: 'Conservative (sum of daily 90th percentiles)' if x == 'p90' else 'Expected demand')
    sku = st.selectbox('Medicine', products.sku.tolist())
with st.spinner('Calculating forecasts and optimisation...'):
    pred = forecast(demand, horizon=horizon)
    orders = optimise(products, pred, budget=budget, service_quantile=target)
    metrics = backtest(demand)
c1, c2, c3, c4 = st.columns(4)
c1.metric('Recommended spend', f"£{orders.order_cost.sum():,.0f}")
c2.metric('Units to purchase', f"{orders.order_units.sum():,.0f}")
c3.metric('Projected demand gap', f"{orders.projected_shortage.sum():,.0f}")
c4.metric('Holdout MAE', f"{metrics['mae']:.2f}")
st.subheader('Historical demand and forecast')
hist = demand[demand.sku == sku].tail(90).rename(columns={'units':'Demand'})
fig = px.line(hist, x='date', y='Demand', title=f'{sku}: last 90 days')
st.plotly_chart(fig, use_container_width=True)
fp = pred[pred.sku == sku]
fig2 = px.line(fp, x='date', y=['mean', 'p10', 'p90'], title='Expected demand and daily predictive quantiles')
st.plotly_chart(fig2, use_container_width=True)
st.subheader('Recommended purchase orders')
st.dataframe(orders, use_container_width=True, hide_index=True)
st.download_button('Download purchase recommendations (CSV)', orders.to_csv(index=False), 'purchase_recommendations.csv', 'text/csv')
st.caption(f"Chronological {metrics['holdout_days']}-day holdout: empirical 80% interval coverage = {metrics['interval_80_coverage']:.1%}. Forecast quantiles are heuristic bootstrap estimates, not calibrated guarantees.")
st.info('Prototype limitations: single supplier per SKU, no licensing validation, no real ERP connection, no expiry/batch controls, and no real-world validation.')
